

<?php $__env->startSection('page'); ?>
<h6 class="font-weight-bolder mb-0">Add Quotation</h6>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>





<div class="row">
    <div class="col-md-12 mt-3">
        <div class="card">
            <form action="<?php echo e(route('savequotation')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="ms-auto text-end">

                    
                    <button type="submit" class="btn btn-link text-dark px-3 mb-0" id="save"><i
                            class="fas fa-save text-dark me-2" aria-hidden="true"></i>Save</button>
                            
                    <a class="btn btn-link text-danger text-gradient px-3 mb-0" id="discard" href="javascript:;"><i
                            class="far fa-trash-alt me-2"></i>Discard</a>
                </div>

                <input type="hidden" name="client_id" value="<?php echo e($lead->client_id); ?>" id="client_id">
                <input type="hidden" name="leads_id" value="<?php echo e($lead->id); ?>" id="leads_id">
                <div class="card-body pt-4 p-3">
                    <div class="d-flex flex-column">
                        <span class="mb-2 text-xs">Contact Name:
                            
                        <input type="text" name="client_name" id="client_name" value="<?php echo e($lead->client_name); ?>"
                            placeholder="Contact Name" />
                        </span>

                        <span class="mb-2 text-xs">GST Treatment:
                            
                            <select name="gst_treatment" id="gst_treatment">
                                <?php $__currentLoopData = $gst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($gt->id); ?>"><?php echo e($gt->gst_treatment); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </span>

                        <span class="mb-2 text-xs">Expiration:
                            
                            <input type="date" name="expiration" id="expiration" placeholder="" />
                        </span>
                        <br>
                        <br>
                        <input type="hidden" name="product_row_count" id="product_row_count">
                        <table class="table mb-0 table-responsive">
                            <thead>
                                <tr>
                                    <th class="text-uppercase" scope="col">
                                        <p class="mb-0 mt-0 text-xs font-weight-bolder">Product</p>
                                    </th>
                                    <th class="text-uppercase" scope="col">
                                        <p class="mb-0 mt-0 text-xs font-weight-bolder">Description</p>
                                    </th>
                                    <th class="text-uppercase" scope="col">
                                        <p class="mb-0 mt-0 text-xs font-weight-bolder">Quantity</p>
                                    </th>
                                    <th class="text-uppercase" scope="col">
                                        <p class="mb-0 mt-0 text-xs font-weight-bolder">Unit Price</p>
                                    </th>
                                    <th class="text-uppercase" scope="col">
                                        <p class="mb-0 mt-0 text-xs font-weight-bolder">Taxes</p>
                                    </th>
                                    <th class="text-uppercase" scope="col">
                                        <p class="mb-0 mt-0 text-xs font-weight-bolder">Subtotal</p>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                        <div>
                            <a class="btn btn-link text-dark px-3 mb-0" id="add_product" href="#"><i
                                    class="fas fa-plus text-dark me-2" aria-hidden="true"></i>Add Product</a>
                        </div>

                        <div class="ms-auto text-end row">
                            <label for="total">Total :</label>
                            <input class="form-control" type="number" name="total" id="total" readonly>
                        </div>
                        
                    </div>                   
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $('#client_name').autocomplete({
        source: function (request, response) {
            $.ajax({
                type: 'get',
                url: "<?php echo e(route('searchrequest')); ?>",
                dataType: "json",
                data: {
                    term: $('#client_name').val()
                },
                success: function (data) {
                    response(data);
                    console.log(data)
                },
            });
        },
        select: function (event, ui) {
            if (ui.item.id != 0) {
                $('#client_id').val(ui.item.id)
                $('#email').val(ui.item.email)
                $('#mobile_no').val(ui.item.phone);
                $('#opportunity').val(ui.item.opportunity);
            }
        },
        minLength: 1,
    });

    window.count = 1;
    $('#add_product').click(function () {
        console.log(window.count);
        $('#product_row_count').val(window.count);
        $('tbody').append(`
                            <tr>
                                <input type="hidden" name="product_id${window.count}" id="product_id${window.count}">
                                <td>
                                    <select name="product_name${window.count}" id="product_name${window.count}" class="form-control select" onchange="getproduct(${window.count})">
                                        <option value="">select</option>
                                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($p); ?>"><?php echo e($p->product_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                                <td><input type="text" class="form-control" name="description${window.count}" id="description${window.count}">
                                </td>
                                <td><input type="number" class="form-control" name="quantity${window.count}" id="quantity${window.count}" onchange="onqtychange()" min="1"></td>
                                <td><input type="number" class="form-control" name="unitPrice${window.count}" id="unitPrice${window.count}" readonly></td>
                                <td>
                                    <select multiple="multiple" name="tax${window.count}[]" id="tax${window.count}" class="form-control" onchange="ontaxchange(${window.count})">
                                        <?php $__currentLoopData = $tax; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($t); ?>"><?php echo e($t->tax_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                                <td><input type="number" class="form-control" name="subtotal${window.count}" id="subtotal${window.count}" readonly></td>
                            </tr>
                        `);
        
        $(`#tax${window.count}`).select2({
                width: '10em',
                placeholder: "select tax",
                allowClear: true
        });
        window.count++;
    });

    function getproduct(count)
    {
        var val = JSON.parse($('#product_name'+count).val());
        console.log('getproduct - '+count);

        $('#product_id'+count).val(val.unique_id)
        $('#description'+count).val(val.description)
        $('#unitPrice'+count).val(val.price)
        $('#subtotal'+count).val(val.price)
        $('#quantity'+count).val(1)
        $('#quantity'+count).attr({
            "max" : val.available_quantity
        })
        ontaxchange();
    }

    function onqtychange(){
        console.log('onqtychange - '+$('#total').val());
        var total = 0; 
        
        for(var i = 1; i<window.count; i++)
        {
            var sub = 0;
            var qty = parseInt($('#quantity'+i).val())
            var u_price = parseFloat($('#unitPrice'+i).val());
            sub = (qty*u_price);
            total = total + sub
            $('#subtotal'+i).val(sub)
        }
        ontaxchange();
    }

    function ontaxchange(){
        // console.log('ontaxchange - '+$('#total').val());
        var total = 0; 
        var sub_total = 0;
        // console.log('here'+window.count)
        for(var i = 1; i<window.count; i++)
        {
            var sub = parseFloat($('#subtotal'+i).val());
            var sub_tax = 0;
            var tax = $('#tax'+i).val();
            var taxLength = Object.keys(tax).length;
            var taxValues = Object.values(tax);
            for(var j=0; j<taxLength; j++){
                var tax_value = parseFloat(JSON.parse(taxValues[j]).tax_value);
                sub_tax = sub_tax + (tax_value / 100)
                console.log('subtax - '+sub_tax);
            }
            sub_total = sub + sub_tax;
            total = total + sub_total;
            console.log('sub_total - '+sub_total);
            // console.log('ontaxchange - '+Object.keys(tax).length);
            // console.log('ontaxchange - '+Object.values(tax)[0]);
        }
        console.log('total - '+total);
        $('#total').val(total.toFixed(2));
    }

    $('tbody').on('change','#tax',function(){
        var total = parseFloat($('#total').val());
        var tax = JSON.parse(this.value).tax_value;
        var total = total+(tax/100);

        $('#total').val(total)

    });

    $('#discard').click(function () {
        window.history.back();
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ModernHeritage\resources\views/frontend/admin/quotation/addQuotation.blade.php ENDPATH**/ ?>
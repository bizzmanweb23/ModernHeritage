

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="content-header row">
    </div>
    <div class="content-body">
        <form action="<?php echo e(route('saveRole')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="role_name">Role Name</label>
                <input type="text" class="form-control" id="role_name" name="role_name"  placeholder="Enter a role name" required>
            </div>
            <br> <br>

            <button type="submit" class="btn btn-primary">Save</button>

            <a href="<?php echo e(route('users')); ?>" class="btn btn-primary">Back</a>
            
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ModernHeritage\resources\views/frontend/admin/role/createRole.blade.php ENDPATH**/ ?>
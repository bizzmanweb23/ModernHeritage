
<?php $__env->startSection('page'); ?>
  <h6 class="font-weight-bolder mb-0">Add User</h6>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    
      
        
          <div class="row">
            <div class="col-xl-4 col-lg-5 col-md-6 d-flex flex-column mx-auto">
              <div class="card card-plain mt-4">
                <div class="content-body">
                  <form method="POST" action="<?php echo e(url('/')); ?>/register/client">
                    <?php echo csrf_field(); ?>
                    <label>First Name</label>
                    <div class="mb-3">
                      <input type="text" class="form-control" name="firstname" id ="firstname" required placeholder="First Name" aria-label="First Name" aria-describedby="first-name-addon">
                    </div>
                    <label>Last Name</label>
                    <div class="mb-3">
                      <input type="text" class="form-control" name="lastname" id ="lastname" required placeholder="Last Name" aria-label="Last Name" aria-describedby="last-name-addon">
                    </div>
                    <label>Email</label>
                    <div class="mb-3">
                      <input type="email" class="form-control" name="email" id ="email" required placeholder="Email" aria-label="Email" aria-describedby="email-addon">
                    </div>
                    <label>Password</label>
                    <div class="mb-3">
                      <input type="password" class="form-control" name="password" id ="password" required placeholder="Password" aria-label="Password" aria-describedby="password-addon">
                    </div>
                    <label>Phone No</label>
                    <div class="mb-3 d-flex">
                        <select name="country_code" class="form-control" style="width: 30em" id="country_code">
                          <option value=""><?php echo e(__('select')); ?></option>
                          <?php $__currentLoopData = $countryCodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="+<?php echo e($c->code); ?>">+<?php echo e($c->code); ?>(<?php echo e($c->name); ?>)</option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="text" class="form-control" style="width: 70em" name="phone" id ="phone" required placeholder="Phone No" aria-label="Phone No" aria-describedby="phone-no-addon">
                    </div>
                    <?php if(Auth::check() && $path=='any'): ?>
                      <label for="role">Role</label>
                      <div class="mb-3">
                          <select name="role" class="form-control" id="role">
                              <option value=""><?php echo e(__('select')); ?></option>
                              <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($r->name); ?>"><?php echo e($r->name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>
                      <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span style="color: red"><?php echo e($message); ?></span>
                      <br>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php endif; ?>
                    <div class="text-center">
                      <button type="submit" class="btn bg-gradient-info w-100 mt-4 mb-0">Save</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        
    
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ModernHeritage\resources\views/frontend/admin/dashboard/adduser.blade.php ENDPATH**/ ?>
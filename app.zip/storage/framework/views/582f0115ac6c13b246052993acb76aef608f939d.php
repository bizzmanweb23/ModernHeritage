

<?php $__env->startSection('page'); ?>
  <h6 class="font-weight-bolder mb-0">Client Data</h6>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


        <form action="<?php echo e(url('/')); ?>/edit/<?php echo e($user->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="unique_id">Unique Id</label>
                <input type="text" class="form-control" id="unique_id" name="unique_id" value="<?php echo e($user->unique_id); ?>" readonly>
            </div>

            <div class="form-group">
                <label for="firstname">Firstname</label>
                <input type="text" class="form-control" id="firstname" name="firstname" value="<?php echo e($user->firstname); ?>" <?php echo e(($route=='edit')?'':'readonly'); ?>>
            </div>

            <div class="form-group">
                <label for="lastname">lastname</label>
                <input type="text" class="form-control" id="lastname" name="lastname" value="<?php echo e($user->lastname); ?>" <?php echo e(($route=='edit')?'':'readonly'); ?>>
            </div>

            <div class="form-group">
                <label for="email">email</label>
                <input type="text" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" <?php echo e(($route=='edit')?'':'readonly'); ?>>
            </div>

            <div class="form-group">
                <label for="phone">Phone</label>
                <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($user->phone); ?>" <?php echo e(($route=='edit')?'':'readonly'); ?>>
            </div>

            <div class="form-group">
                <label for="address">Address</label>
                <input type="text" class="form-control" id="address" name="address" value="<?php echo e($user->address); ?>" <?php echo e(($route=='edit')?'':'readonly'); ?>>
            </div>

            <div class="form-group">
                <label for="state">State</label>
                <input type="text" class="form-control" id="state" name="state" value="<?php echo e($user->state); ?>" <?php echo e(($route=='edit')?'':'readonly'); ?>>
            </div>

            <div class="form-group">
                <label for="zipcode">Zipcode</label>
                <input type="text" class="form-control" id="zipcode" name="zipcode" value="<?php echo e($user->zipcode); ?>" <?php echo e(($route=='edit')?'':'readonly'); ?>>
            </div>

            <div class="form-group">
                <label for="country">Country</label>
                <input type="text" class="form-control" id="country" name="country" value="<?php echo e($user->country); ?>" <?php echo e(($route=='edit')?'':'readonly'); ?>>
            </div>


            <div class="form-group">
                <label for="device_id">Device ID</label>
                <input type="text" class="form-control" id="device_id" name="device_id" value="<?php echo e($user->device_id); ?>" <?php echo e(($route=='edit')?'':'readonly'); ?>>
            </div>

            <div class="form-group">
                <label for="device_name">Device name</label>
                <input type="text" class="form-control" id="device_name" name="device_name"
                    value="<?php echo e($user->device_name); ?>" <?php echo e(($route=='edit')?'':'readonly'); ?>>
            </div>

        
            <br> <br>
            <?php if($route == 'edit'): ?>

            <button type="submit" class="btn btn-primary">Save</button>

            <?php endif; ?>

            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary">Back</a>
            
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ModernHeritage\resources\views/frontend/admin/dashboard/memberData.blade.php ENDPATH**/ ?>
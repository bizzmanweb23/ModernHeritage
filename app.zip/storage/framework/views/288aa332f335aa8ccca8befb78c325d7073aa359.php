

<?php $__env->startSection('page'); ?>
<h6 class="font-weight-bolder mb-0">Confirm Quotation</h6>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 mt-3">
        <div class="card">
            <form action="<?php echo e(url('/')); ?>/confirmquotation/<?php echo e($quotation->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="ms-auto text-end">
                    <?php if(isset($quotation->sales_id)): ?>
                        
                    <?php else: ?>
                    <button type="submit" class="btn btn-link text-dark px-3 mb-0" id="confirm"><i
                            class="fas fa-save text-dark me-2" aria-hidden="true"></i>Confirm</button>
                    <a class="btn btn-link text-danger text-gradient px-3 mb-0" id="discard" href="javascript:;"><i
                            class="far fa-trash-alt me-2"></i>Discard</a>
                    <?php endif; ?>
                </div>  

                <input type="hidden" name="customer_id" value="<?php echo e($quotation->customer_id); ?>" id="customer_id">
                <input type="hidden" name="quotation_id" value="<?php echo e($quotation->id); ?>" id="quotation_id">
                <div class="card-header pb-0 px-3">
                    <div class="d-flex flex-column">
                    <?php if(isset($quotation->sales_id)): ?>
                        <h5 class="mb-0" id="sales_id">Sales Id : <?php echo e($quotation->sales_id); ?></h5>   
                    <?php endif; ?>                   
                    <h5 class="mb-0" id="quotation_unique_id">Quotation Id : <?php echo e($quotation->quotation_unique_id); ?></h5>
                    </div>
                </div>
                <div class="card-body pt-4 p-3">
                    <div class="d-flex flex-column">
                        <span class="mb-2 text-xs">Contact Name:
                            <span class="text-dark font-weight-bold ms-sm-2" id="client_name"><?php echo e($quotation->client_name); ?></span>
                        </span>

                        <span class="mb-2 text-xs">GST Treatment:
                            <span class="text-dark font-weight-bold ms-sm-2" id="gst_treatment"><?php echo e($quotation->gst_treatment_name); ?></span>
                        </span>

                        
                        <span class="mb-2 text-xs">Expiration:
                            <span class="text-dark font-weight-bold ms-sm-2" id="expiration"><?php echo e($quotation->expiration); ?></span>
                        </span>
                        <br>
                        <br>
                        <input type="hidden" name="product_id" id="product_id">
                        <table class="table mb-0 table-responsive">
                            <thead>
                                <tr>
                                    <th class="text-uppercase" scope="col">
                                        <p class="mb-0 mt-0 text-xs font-weight-bolder">Product</p>
                                    </th>
                                    <th class="text-uppercase" scope="col">
                                        <p class="mb-0 mt-0 text-xs font-weight-bolder">Description</p>
                                    </th>
                                    <th class="text-uppercase" scope="col">
                                        <p class="mb-0 mt-0 text-xs font-weight-bolder">Quantity</p>
                                    </th>
                                    <th class="text-uppercase" scope="col">
                                        <p class="mb-0 mt-0 text-xs font-weight-bolder">Unit Price</p>
                                    </th>
                                    <th class="text-uppercase" scope="col">
                                        <p class="mb-0 mt-0 text-xs font-weight-bolder">Taxes</p>
                                    </th>
                                    <th class="text-uppercase" scope="col">
                                        <p class="mb-0 mt-0 text-xs font-weight-bolder">Subtotal</p>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $quotation_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <span class="text-dark font-weight-bold ms-sm-2" id="product_name"><?php echo e($qp->product_name); ?></span>
                                    </td>
                                    <td>
                                        <span class="text-dark font-weight-bold ms-sm-2" id="description"><?php echo e($qp->description); ?></span>
                                    </td>
                                    <td>
                                        <span class="text-dark font-weight-bold ms-sm-2" id="quantity"><?php echo e($qp->quantity); ?></span>
                                    </td>
                                    <td>
                                        <span class="text-dark font-weight-bold ms-sm-2" id="price"><?php echo e($qp->price); ?></span>
                                    </td>
                                    <td>
                                        <span class="text-dark font-weight-bold ms-sm-2" id="tax">
                                            <?php $__currentLoopData = $qp->selected_taxs_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($tax_name); ?> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="text-dark font-weight-bold ms-sm-2" id="subtotal"><?php echo e($qp->price * $qp->quantity); ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        

                        <div class="ms-auto text-end row">
                            <label for="total">Total :</label>
                            <span class="text-dark font-weight-bold ms-sm-2" id="total"><?php echo e($qp->total); ?></span>
                        </div>
                        
                    </div>                   
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ModernHeritage\resources\views/frontend/admin/quotation/confirmquotation.blade.php ENDPATH**/ ?>